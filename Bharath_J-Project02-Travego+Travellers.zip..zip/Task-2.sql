use travego;
select * from passenger;
select * from price;
--    

--  A..How many female passengers traveled a minimum distance of 600 KMs?

select passenger_name from  passenger where Gender='F' and distance >=600;

select count(*) as female_passenger from passenger
where Gender='F' and Distance>=600;

--  B..Write a query to display the passenger details whose travel distance is greater than 500 and who are traveling in a sleeper bus. 

select * from passenger where Distance >=500 and Bus_type ='Sleeper';

--  c. c.Select passenger names whose names start with the character 'S

select * from passenger where Passenger_name like 'S%';

--  d Calculate the price charged for each passenger, displaying the Passenger name, Boarding City,
--  Destination City, Bus type, and Price in the output. 

select p.passenger_name,p.Boarding_city,p.Destination_city,p.Bus_type,pr.price 
from passenger p
inner join  
price pr on p.Bus_type=pr.Bus_type and p.Distance= pr.Distance;

-- e.What are the passenger name(s) and the ticket price for those who traveled 1000 KMs Sitting in
-- a bus?



select p.Passenger_name,pr.price 
from passenger p
inner join price pr on p.Bus_Type = pr.Bus_Type and p.Distance =pr.Distance
where p.distance = 1000 and p.Bus_Type='Sitting';


-- f. What will be the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji?

select p.passenger_name,pr.Bus_type,pr.price
from passenger p
inner join price pr on p.Bus_Type=pr.Bus_Type and p.Distance =pr.Distance
where p.Passenger_name='Pallavi' and p.Boarding_city='Bengaluru' and p.Destination_city='Panaji';



select * from passenger;
--  g. Alter the column category with the value "Non-AC" where the Bus_Type is sleeper


update passenger 
set Category='Non-AC' 
where Bus_type='Sleeper';

select * from passenger;

-- h.Delete an entry from the table where the passenger name is Piyush and commit this change in
-- the database. (1 mark)

delete from  passenger where passenger_name='Piyush';

commit;

-- i.Truncate the table passenger and comment on the number of rows in the table (explain if
-- required). (

Truncate table passenger;

select count(*) as row_count
from passenger;

-- After executing the truncate statement, the table will be empty, and the row count will be zero.

--  j. Delete the table passenger from the database.
drop table passenger ;


